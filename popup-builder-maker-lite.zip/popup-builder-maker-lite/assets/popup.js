/**
 * Popup Builder & Maker Lite - Frontend JavaScript
 * Vanilla JavaScript - No jQuery
 */

(function () {
    'use strict';

    var STORAGE_KEY = 'pbml_popup_closed';
    var overlay, modal, closeBtn;
    var showTimer, closeIconTimer, autoCloseTimer;
    var settings;

    function init() {
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', setup);
        } else {
            setup();
        }
    }

    function setup() {
        settings = window.pbmlSettings || {};

        // Check if already dismissed
        if (isDismissed()) {
            removePopup();
            return;
        }

        overlay = document.getElementById('pbml-overlay');
        closeBtn = document.getElementById('pbml-close');

        if (!overlay || !closeBtn) return;

        modal = overlay.querySelector('.pbml-modal');

        // Set animation attribute
        if (settings.animation) {
            overlay.setAttribute('data-animation', settings.animation);
        }

        var showAfter = (settings.showAfter || 5) * 1000;
        var closeIconAfter = (settings.closeIconAfter || 20) * 1000;
        var stayDuration = (settings.stayDuration || 0) * 1000;

        // Schedule popup display
        showTimer = setTimeout(function () {
            showPopup();

            // Show close button after delay
            closeIconTimer = setTimeout(function () {
                showCloseBtn();
            }, closeIconAfter);

            // Auto-close if configured
            if (stayDuration > 0) {
                autoCloseTimer = setTimeout(function () {
                    hidePopup();
                }, stayDuration);
            }
        }, showAfter);

        bindEvents();
    }

    function isDismissed() {
        try {
            if (settings.sessionOnly) {
                return sessionStorage.getItem(STORAGE_KEY) === '1';
            }
            // Use cookies for accurate expiry check
            return getCookie(STORAGE_KEY) === '1';
        } catch (e) {
            return getCookie(STORAGE_KEY) === '1';
        }
    }

    function setDismissed() {
        var days = (typeof settings.cookieDays !== 'undefined') ? parseInt(settings.cookieDays) : 7;

        // If 0 days, do not save status (show on every page load)
        if (days === 0) return;

        try {
            if (settings.sessionOnly) {
                sessionStorage.setItem(STORAGE_KEY, '1');
            } else {
                // Use cookies for accurate day-based expiry (localStorage doesn't expire)
                setCookie(STORAGE_KEY, '1', days);
            }
        } catch (e) {
            setCookie(STORAGE_KEY, '1', days);
        }
    }

    function getCookie(name) {
        var match = document.cookie.match(new RegExp('(^| )' + name + '=([^;]+)'));
        return match ? match[2] : null;
    }

    function setCookie(name, value, days) {
        var d = new Date();
        d.setTime(d.getTime() + (days * 86400000));
        document.cookie = name + '=' + value + ';expires=' + d.toUTCString() + ';path=/;SameSite=Lax';
    }

    function removePopup() {
        var el = document.getElementById('pbml-overlay');
        if (el && el.parentNode) el.parentNode.removeChild(el);
    }

    function showPopup() {
        if (!overlay) return;
        overlay.classList.add('pbml-active');
        overlay.setAttribute('aria-hidden', 'false');

        if (modal) {
            modal.setAttribute('tabindex', '-1');
            modal.focus();
        }

        document.addEventListener('keydown', handleKeys);
    }

    function showCloseBtn() {
        if (!closeBtn) return;
        closeBtn.style.display = 'flex';
        requestAnimationFrame(function () {
            closeBtn.classList.add('pbml-visible');
        });
    }

    function hidePopup() {
        if (!overlay) return;
        overlay.classList.remove('pbml-active');
        overlay.setAttribute('aria-hidden', 'true');
        setDismissed();
        clearAllTimers();
        document.removeEventListener('keydown', handleKeys);

        setTimeout(removePopup, 400);
    }

    function clearAllTimers() {
        if (showTimer) clearTimeout(showTimer);
        if (closeIconTimer) clearTimeout(closeIconTimer);
        if (autoCloseTimer) clearTimeout(autoCloseTimer);
    }

    function bindEvents() {
        // Close button
        closeBtn.addEventListener('click', function (e) {
            e.preventDefault();
            e.stopPropagation();
            hidePopup();
        });

        // Overlay click
        if (settings.closeOnOverlay !== false) {
            overlay.addEventListener('click', function (e) {
                if (e.target === overlay && closeBtn.classList.contains('pbml-visible')) {
                    hidePopup();
                }
            });
        }
    }

    function handleKeys(e) {
        // ESC key
        if (e.key === 'Escape' && settings.closeOnEsc !== false) {
            if (closeBtn && closeBtn.classList.contains('pbml-visible')) {
                hidePopup();
            }
        }

        // Tab trap
        if (e.key === 'Tab' && modal) {
            trapFocus(e);
        }
    }

    function trapFocus(e) {
        var focusable = modal.querySelectorAll('button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])');
        if (!focusable.length) return;

        var first = focusable[0];
        var last = focusable[focusable.length - 1];

        if (e.shiftKey) {
            if (document.activeElement === first) {
                last.focus();
                e.preventDefault();
            }
        } else {
            if (document.activeElement === last) {
                first.focus();
                e.preventDefault();
            }
        }
    }

    init();
})();
