/**
 * Popup Builder & Maker Lite - Admin JavaScript
 */
jQuery(document).ready(function ($) {

    // Tab navigation
    $('.pbml-tab').on('click', function () {
        var tab = $(this).data('tab');
        $('.pbml-tab').removeClass('active');
        $(this).addClass('active');
        $('.pbml-panel').removeClass('active');
        $('.pbml-panel[data-panel="' + tab + '"]').addClass('active');
    });

    // Color pickers
    $('.pbml-color').wpColorPicker();

    // Mode switcher
    $('.pbml-mode-btn').on('click', function () {
        var mode = $(this).data('mode');
        $('.pbml-mode-btn').removeClass('active');
        $(this).addClass('active');
        $('#pbml-color-mode').val(mode);

        // Apply preset via AJAX
        $.post(pbmlAdmin.ajaxurl, {
            action: 'pbml_apply_preset',
            nonce: pbmlAdmin.nonce,
            mode: mode
        }, function (response) {
            if (response.success) {
                var preset = response.data;

                // Update color pickers
                if (preset.popup_bg_color) {
                    $('#pbml-popup-bg').val(preset.popup_bg_color).wpColorPicker('color', preset.popup_bg_color);
                }
                if (preset.headline_color) {
                    $('#pbml-headline-color').val(preset.headline_color).wpColorPicker('color', preset.headline_color);
                }
                if (preset.description_color) {
                    $('#pbml-desc-color').val(preset.description_color).wpColorPicker('color', preset.description_color);
                }
                if (preset.button_bg_color) {
                    $('#pbml-btn-bg').val(preset.button_bg_color).wpColorPicker('color', preset.button_bg_color);
                }
                if (preset.button_text_color) {
                    $('#pbml-btn-text').val(preset.button_text_color).wpColorPicker('color', preset.button_text_color);
                }
                if (preset.close_btn_color) {
                    $('#pbml-close-color').val(preset.close_btn_color).wpColorPicker('color', preset.close_btn_color);
                }
                if (preset.outline_color) {
                    $('#pbml-outline-color').val(preset.outline_color).wpColorPicker('color', preset.outline_color);
                }
            }
        });
    });

    // Media uploader
    var mediaUploader;
    $('#pbml-upload-btn').on('click', function (e) {
        e.preventDefault();
        if (mediaUploader) {
            mediaUploader.open();
            return;
        }
        mediaUploader = wp.media({
            title: 'Select Image',
            button: { text: 'Use this image' },
            multiple: false
        });
        mediaUploader.on('select', function () {
            var attachment = mediaUploader.state().get('selection').first().toJSON();
            $('#pbml-image-url').val(attachment.url);
            $('#pbml-preview').addClass('has-image').html('<img src="' + attachment.url + '" alt="">');
            $('#pbml-remove-btn').show();
        });
        mediaUploader.open();
    });

    $('#pbml-remove-btn').on('click', function (e) {
        e.preventDefault();
        $('#pbml-image-url').val('');
        $('#pbml-preview').removeClass('has-image').html('<span style="color:#94a3b8">No image</span>');
        $(this).hide();
    });

    // Export settings
    $('#pbml-export-btn').on('click', function () {
        var $btn = $(this);
        $btn.prop('disabled', true).text('Exporting...');

        $.post(pbmlAdmin.ajaxurl, {
            action: 'pbml_export_settings',
            nonce: pbmlAdmin.nonce
        }, function (response) {
            if (response.success) {
                var dataStr = JSON.stringify(response.data.json_raw, null, 4);
                var blob = new Blob([dataStr], { type: 'application/json' });
                var url = URL.createObjectURL(blob);
                var a = document.createElement('a');
                a.href = url;
                a.download = response.data.filename;
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
                URL.revokeObjectURL(url);
            }
            $btn.prop('disabled', false).text('📥 Export Settings');
        });
    });

    // Handle File Import
    $('#pbml-import-file').on('change', function (e) {
        var file = e.target.files[0];
        if (!file) return;

        var reader = new FileReader();
        var $status = $('#pbml-import-status');

        reader.onload = function (e) {
            var content = e.target.result;
            try {
                JSON.parse(content);
                $status.css('color', '#4f46e5').text('Importing...');

                $.post(pbmlAdmin.ajaxurl, {
                    action: 'pbml_import_settings',
                    nonce: pbmlAdmin.nonce,
                    import_data: content
                }, function (response) {
                    if (response.success) {
                        $status.css('color', '#10b981').text(response.data.message);
                        setTimeout(function () { location.reload(); }, 1200);
                    } else {
                        $status.css('color', '#ef4444').text(response.data.message);
                    }
                });
            } catch (err) {
                $status.css('color', '#ef4444').text('Invalid JSON file.');
            }
        };
        reader.readAsText(file);
    });
});
