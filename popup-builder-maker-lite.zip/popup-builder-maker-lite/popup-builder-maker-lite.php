<?php
/**
 * Plugin Name: Popup Builder & Maker Lite
 * Plugin URI: https://github.com/waqarrasheed900/Popup-Builder-Maker-Lite
 * Description: A lightweight, fast WordPress popup plugin with modern UI, dark/light mode, import/export, and full customization. Compatible with all themes.
 * Version: 1.4.0
 * Author: Waqar Rasheed
 * License: GPL v2 or later
 * Text Domain: popup-builder-maker-lite
 */

if (!defined('ABSPATH')) exit;

define('PBML_VERSION', '1.4.0');
define('PBML_PLUGIN_FILE', __FILE__);
define('PBML_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('PBML_PLUGIN_URL', plugin_dir_url(__FILE__));
define('PBML_PLUGIN_BASENAME', plugin_basename(__FILE__));

class Popup_Builder_Maker_Lite {

    private static $instance = null;

    // Light Mode Preset (for dark websites - popup is light)
    private $light_preset = array(
        'popup_bg_color'     => '#ffffff',
        'headline_color'     => '#1e293b',
        'description_color'  => '#475569',
        'button_bg_color'    => '#2563eb',
        'button_text_color'  => '#ffffff',
        'close_btn_color'    => '#64748b',
        'outline_color'      => '#e2e8f0',
    );

    // Dark Mode Preset (for light/white websites - popup is dark, stands out)
    private $dark_preset = array(
        'popup_bg_color'     => '#1e293b',
        'headline_color'     => '#ffffff',
        'description_color'  => '#cbd5e1',
        'button_bg_color'    => '#fbbf24',
        'button_text_color'  => '#1e293b',
        'close_btn_color'    => '#94a3b8',
        'outline_color'      => '#334155',
    );

    private $defaults = array(
        // General
        'enabled'               => '1',
        'color_mode'            => 'dark',
        'show_after'            => 3,
        'stay_duration'         => 0,
        'close_icon_after'      => 5,
        'close_on_overlay'      => '1',
        'close_on_esc'          => '1',
        'show_once_per_session' => '0',
        'cookie_days'           => 1,
        'display_on_all'        => '1',
        'include_pages'         => '',
        'include_pages'         => '',
        'exclude_pages'         => '',
        
        // Popup Type
        'popup_type'            => 'content', // content | image
        'image_link'            => '',
        'image_link_target'     => '0',
        
        // Appearance
        'width_desktop'         => 520,
        'width_tablet'          => 440,
        'width_mobile'          => 340,
        'popup_bg_color'        => '#1e293b',
        'overlay_color'         => '#0f172a',
        'overlay_opacity'       => 0.75,
        'border_radius'         => 20,
        'enable_shadow'         => '1',
        'popup_padding'         => 40,
        'animation_style'       => 'fade-scale',
        'enable_outline'        => '1',
        'outline_color'         => '#334155',
        'outline_width'         => 2,
        
        // Content
        'popup_image'           => '',
        'image_position'        => 'top',
        'headline'              => 'Get Your Free iPhone Today!',
        'headline_color'        => '#ffffff',
        'headline_size'         => 28,
        'headline_align'        => 'center',
        'description'           => 'Check your eligibility now and apply for a discounted or free government iPhone with unlimited monthly internet. Limited time offer!',
        'description_color'     => '#cbd5e1',
        'description_size'      => 16,
        'description_align'     => 'center',
        'html_content'          => '',
        
        // Button
        'button_enabled'        => '1',
        'button_text'           => 'Apply Now →',
        'button_url'            => '#',
        'button_new_tab'        => '0',
        'button_bg_color'       => '#fbbf24',
        'button_text_color'     => '#1e293b',
        'button_size'           => 16,
        'button_radius'         => 10,
        'button_full_width'     => '0',
        
        // Close Button
        'close_btn_color'       => '#94a3b8',
        'close_btn_size'        => 32,
    );

    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_init', array($this, 'register_settings'));
        add_action('admin_enqueue_scripts', array($this, 'admin_enqueue_scripts'));
        add_filter('plugin_action_links_' . PBML_PLUGIN_BASENAME, array($this, 'add_settings_link'));
        add_action('wp_ajax_pbml_export_settings', array($this, 'ajax_export_settings'));
        add_action('wp_ajax_pbml_import_settings', array($this, 'ajax_import_settings'));
        add_action('wp_ajax_pbml_apply_preset', array($this, 'ajax_apply_preset'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_frontend_assets'));
        add_action('wp_footer', array($this, 'render_popup'));
    }

    public function add_settings_link($links) {
        array_unshift($links, '<a href="' . admin_url('options-general.php?page=popup-builder-maker-lite') . '">Settings</a>');
        return $links;
    }

    public function add_admin_menu() {
        add_options_page('Popup Builder & Maker Lite', 'Popup Builder Lite', 'manage_options', 'popup-builder-maker-lite', array($this, 'render_admin_page'));
    }

    public function register_settings() {
        register_setting('pbml_settings_group', 'pbml_options', array($this, 'sanitize_options'));
    }

    public function sanitize_options($input) {
        $s = array();
        if (!is_array($input)) return $this->defaults;
        
        $checkboxes = array('enabled', 'enable_shadow', 'close_on_overlay', 'close_on_esc', 'button_enabled', 'button_new_tab', 'image_link_target', 'button_full_width', 'show_once_per_session', 'display_on_all', 'enable_outline');
        foreach ($checkboxes as $cb) { $s[$cb] = isset($input[$cb]) ? '1' : '0'; }
        
        $integers = array('show_after', 'stay_duration', 'close_icon_after', 'cookie_days', 'width_desktop', 'width_tablet', 'width_mobile', 'border_radius', 'popup_padding', 'headline_size', 'description_size', 'button_size', 'button_radius', 'close_btn_size', 'outline_width');
        foreach ($integers as $int) { $s[$int] = isset($input[$int]) ? absint($input[$int]) : $this->defaults[$int]; }
        
        $s['overlay_opacity'] = isset($input['overlay_opacity']) ? max(0, min(1, floatval($input['overlay_opacity']))) : $this->defaults['overlay_opacity'];
        
        $colors = array('popup_bg_color', 'overlay_color', 'headline_color', 'description_color', 'button_bg_color', 'button_text_color', 'close_btn_color', 'outline_color');
        foreach ($colors as $color) { $s[$color] = isset($input[$color]) ? sanitize_hex_color($input[$color]) : $this->defaults[$color]; }
        
        $s['headline'] = isset($input['headline']) ? sanitize_text_field($input['headline']) : '';
        $s['description'] = isset($input['description']) ? wp_kses_post($input['description']) : '';
        $s['html_content'] = isset($input['html_content']) ? wp_kses_post($input['html_content']) : '';
        $s['button_text'] = isset($input['button_text']) ? sanitize_text_field($input['button_text']) : '';
        $s['button_url'] = isset($input['button_url']) ? esc_url_raw($input['button_url']) : '';
        $s['popup_image'] = isset($input['popup_image']) ? esc_url_raw($input['popup_image']) : '';
        $s['include_pages'] = isset($input['include_pages']) ? sanitize_text_field($input['include_pages']) : '';
        $s['exclude_pages'] = isset($input['exclude_pages']) ? sanitize_text_field($input['exclude_pages']) : '';
        $s['color_mode'] = isset($input['color_mode']) && in_array($input['color_mode'], array('dark', 'light')) ? $input['color_mode'] : 'dark';
        $s['headline_align'] = isset($input['headline_align']) ? $input['headline_align'] : 'center';
        $s['description_align'] = isset($input['description_align']) ? $input['description_align'] : 'center';
        $s['image_position'] = isset($input['image_position']) ? $input['image_position'] : 'top';
        $s['animation_style'] = isset($input['animation_style']) ? $input['animation_style'] : 'fade-scale';
        $s['image_position'] = isset($input['image_position']) ? $input['image_position'] : 'top';
        $s['animation_style'] = isset($input['animation_style']) ? $input['animation_style'] : 'fade-scale';
        $s['popup_type'] = isset($input['popup_type']) && in_array($input['popup_type'], array('content', 'image')) ? $input['popup_type'] : 'content';
        $s['image_link'] = isset($input['image_link']) ? esc_url_raw($input['image_link']) : '';
        
        return $s;
    }

    public function get_options() {
        return wp_parse_args(get_option('pbml_options', array()), $this->defaults);
    }

    public function ajax_apply_preset() {
        check_ajax_referer('pbml_nonce', 'nonce');
        if (!current_user_can('manage_options')) wp_die();
        
        $mode = isset($_POST['mode']) ? sanitize_text_field(wp_unslash($_POST['mode'])) : '';
        $preset = ($mode === 'light') ? $this->light_preset : $this->dark_preset;
        $preset['color_mode'] = $mode;
        
        wp_send_json_success($preset);
    }

    public function ajax_export_settings() {
        check_ajax_referer('pbml_nonce', 'nonce');
        if (!current_user_can('manage_options')) wp_die();
        wp_send_json_success(array('json_raw' => $this->get_options(), 'filename' => 'popup-settings-' . gmdate('Y-m-d') . '.json'));
    }

    public function ajax_import_settings() {
        check_ajax_referer('pbml_nonce', 'nonce');
        if (!current_user_can('manage_options')) wp_die();
        
        $import_data = isset($_POST['import_data']) ? sanitize_textarea_field(wp_unslash($_POST['import_data'])) : '';
        if (empty($import_data)) wp_send_json_error(array('message' => 'No data provided'));

        $decoded = json_decode(stripslashes($import_data), true);
        if (!$decoded) $decoded = json_decode(base64_decode($import_data), true);
        
        if ($decoded) {
            update_option('pbml_options', $this->sanitize_options($decoded));
            wp_send_json_success(array('message' => 'Imported! Refreshing...'));
        }
        wp_send_json_error(array('message' => 'Invalid File'));
    }

    public function admin_enqueue_scripts($hook) {
        if ('settings_page_popup-builder-maker-lite' !== $hook) return;
        wp_enqueue_media();
        wp_enqueue_style('wp-color-picker');
        wp_enqueue_script('wp-color-picker');
        wp_register_style('pbml-admin', false, array(), PBML_VERSION);
        wp_enqueue_style('pbml-admin');
        wp_add_inline_style('pbml-admin', $this->get_admin_css());
        wp_enqueue_script('pbml-admin', PBML_PLUGIN_URL . 'assets/admin.js', array('jquery', 'wp-color-picker'), PBML_VERSION, true);
        wp_localize_script('pbml-admin', 'pbmlAdmin', array('nonce' => wp_create_nonce('pbml_nonce'), 'ajaxurl' => admin_url('admin-ajax.php')));
    }

    private function get_admin_css() {
        return '
        .pbml-wrap { max-width: 1000px; margin: 20px auto; background: #fff; border-radius: 16px; box-shadow: 0 20px 50px rgba(0,0,0,0.08); overflow: hidden; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; }
        .pbml-header { background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%); padding: 28px 35px; display: flex; justify-content: space-between; align-items: center; border-bottom: 4px solid #fbbf24; }
        .pbml-header h1 { margin: 0; font-size: 22px; color: #fff !important; font-weight: 700; }
        .pbml-header .version { background: #fbbf24; color: #1e293b; padding: 4px 12px; border-radius: 20px; font-size: 11px; font-weight: 700; }
        .pbml-tabs { display: flex; background: #f8fafc; border-bottom: 1px solid #e2e8f0; overflow-x: auto; }
        .pbml-tab { padding: 16px 24px; cursor: pointer; font-weight: 600; color: #64748b; border-bottom: 3px solid transparent; white-space: nowrap; transition: all .2s; }
        .pbml-tab:hover { background: #fff; color: #1e293b; }
        .pbml-tab.active { color: #4f46e5; border-bottom-color: #4f46e5; background: #fff; }
        .pbml-content { padding: 35px; }
        .pbml-panel { display: none; }
        .pbml-panel.active { display: block; animation: pbmlFade .3s ease; }
        @keyframes pbmlFade { from { opacity: 0; } to { opacity: 1; } }
        .pbml-section { margin-bottom: 35px; background: #f8fafc; border: 1px solid #e2e8f0; padding: 25px; border-radius: 14px; }
        .pbml-section:last-child { margin-bottom: 0; }
        .pbml-section-title { font-size: 16px; font-weight: 700; margin-bottom: 20px; color: #1e293b; display: flex; align-items: center; gap: 10px; }
        .pbml-section-title svg { width: 20px; height: 20px; color: #4f46e5; }
        .pbml-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: 20px; }
        .pbml-field { margin-bottom: 18px; }
        .pbml-field:last-child { margin-bottom: 0; }
        .pbml-field label { display: block; font-weight: 600; margin-bottom: 8px; color: #475569; font-size: 13px; }
        .pbml-field input[type="text"], .pbml-field input[type="number"], .pbml-field input[type="url"], .pbml-field textarea, .pbml-field select { width: 100%; padding: 12px 14px; border: 1px solid #e2e8f0; border-radius: 10px; font-size: 14px; transition: .2s; background: #fff; }
        .pbml-field input:focus, .pbml-field textarea:focus, .pbml-field select:focus { outline: none; border-color: #4f46e5; box-shadow: 0 0 0 3px rgba(79,70,229,0.1); }
        .pbml-field textarea { min-height: 100px; }
        .pbml-field .hint { font-size: 11px; color: #94a3b8; margin-top: 6px; }
        .pbml-toggle { display: flex; align-items: center; gap: 14px; padding: 18px; background: #fff; border: 1px solid #e2e8f0; border-radius: 12px; cursor: pointer; transition: .2s; }
        .pbml-toggle:hover { border-color: #cbd5e1; }
        .pbml-toggle input { display: none; }
        .pbml-toggle .switch { width: 48px; height: 26px; background: #e2e8f0; border-radius: 13px; position: relative; transition: .3s; flex-shrink: 0; }
        .pbml-toggle .switch::after { content: ""; position: absolute; width: 20px; height: 20px; background: #fff; border-radius: 50%; top: 3px; left: 3px; transition: .3s; box-shadow: 0 1px 3px rgba(0,0,0,0.15); }
        .pbml-toggle input:checked + .switch { background: #10b981; }
        .pbml-toggle input:checked + .switch::after { transform: translateX(22px); }
        .pbml-toggle .toggle-text { line-height: 1.4; }
        .pbml-toggle .toggle-label { font-weight: 700; color: #1e293b; font-size: 14px; }
        .pbml-toggle .toggle-desc { font-size: 12px; color: #64748b; margin-top: 2px; }
        .pbml-btn { padding: 14px 28px; border-radius: 10px; font-size: 14px; font-weight: 700; cursor: pointer; transition: all .2s; border: none; display: inline-flex; align-items: center; gap: 8px; }
        .pbml-btn-primary { background: #4f46e5; color: #fff; box-shadow: 0 4px 14px rgba(79,70,229,0.35); }
        .pbml-btn-primary:hover { background: #4338ca; transform: translateY(-2px); }
        .pbml-btn-secondary { background: #fff; color: #475569; border: 1px solid #e2e8f0; }
        .pbml-btn-secondary:hover { background: #f8fafc; border-color: #cbd5e1; }
        .pbml-mode-switcher { display: flex; gap: 12px; margin-bottom: 25px; }
        .pbml-mode-btn { flex: 1; padding: 20px; border: 2px solid #e2e8f0; border-radius: 14px; cursor: pointer; text-align: center; transition: all .2s; background: #fff; }
        .pbml-mode-btn:hover { border-color: #cbd5e1; }
        .pbml-mode-btn.active { border-color: #4f46e5; background: #f5f3ff; }
        .pbml-mode-btn .mode-icon { font-size: 32px; margin-bottom: 8px; }
        .pbml-mode-btn .mode-title { font-weight: 700; color: #1e293b; font-size: 15px; }
        .pbml-mode-btn .mode-desc { font-size: 12px; color: #64748b; margin-top: 4px; }
        .pbml-image-upload { display: flex; gap: 15px; align-items: flex-start; }
        .pbml-image-preview { width: 140px; height: 90px; border: 2px dashed #e2e8f0; border-radius: 10px; display: flex; align-items: center; justify-content: center; background: #f8fafc; overflow: hidden; flex-shrink: 0; }
        .pbml-image-preview.has-image { border-style: solid; }
        .pbml-image-preview img { max-width: 100%; max-height: 100%; object-fit: contain; }
        .pbml-footer { border-top: 1px solid #e2e8f0; padding: 25px 35px; background: #f8fafc; display: flex; justify-content: space-between; align-items: center; }
        .pbml-color-preview { display: flex; gap: 8px; margin-top: 15px; flex-wrap: wrap; }
        .pbml-color-swatch { width: 36px; height: 36px; border-radius: 8px; border: 2px solid #fff; box-shadow: 0 2px 6px rgba(0,0,0,0.15); }
        .pbml-radio-group { display: flex; gap: 15px; background: #f8fafc; padding: 5px; border-radius: 10px; border: 1px solid #e2e8f0; width: fit-content; }
        .pbml-radio-option { position: relative; cursor: pointer; }
        .pbml-radio-option input { display: none; }
        .pbml-radio-option span { display: block; padding: 8px 16px; border-radius: 8px; font-weight: 600; font-size: 13px; color: #64748b; transition: .2s; }
        .pbml-radio-option input:checked + span { background: #fff; color: #4f46e5; box-shadow: 0 2px 6px rgba(0,0,0,0.05); border: 1px solid #e2e8f0; }
        @media (max-width: 768px) { .pbml-grid { grid-template-columns: 1fr; } .pbml-mode-switcher { flex-direction: column; } }
        ';
    }

    public function render_admin_page() {
        $o = $this->get_options();
        ?>
        <div class="pbml-wrap">
            <div class="pbml-header">
                <h1>🎯 Popup Builder & Maker Lite</h1>
                <span class="version">v<?php echo esc_html(PBML_VERSION); ?></span>
            </div>
            <div class="pbml-tabs">
                <div class="pbml-tab active" data-tab="general">General</div>
                <div class="pbml-tab" data-tab="content">Content</div>
                <div class="pbml-tab" data-tab="appearance">Appearance</div>
                <div class="pbml-tab" data-tab="button">Button</div>
                <div class="pbml-tab" data-tab="targeting">Display</div>
                <div class="pbml-tab" data-tab="advanced">Advanced</div>
            </div>
            <div class="pbml-content">
                <form method="post" action="options.php" id="pbml-form">
                    <?php settings_fields('pbml_settings_group'); ?>
                    
                    <!-- GENERAL -->
                    <div class="pbml-panel active" data-panel="general">
                        <div class="pbml-section">
                            <h3 class="pbml-section-title">
                                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"/></svg>
                                Popup Status
                            </h3>
                            <label class="pbml-toggle">
                                <input type="checkbox" name="pbml_options[enabled]" value="1" <?php checked($o['enabled'], '1'); ?>>
                                <span class="switch"></span>
                                <div class="toggle-text">
                                    <div class="toggle-label">Enable Popup</div>
                                    <div class="toggle-desc">Show popup site-wide when enabled</div>
                                </div>
                            </label>
                        </div>
                        
                        <div class="pbml-section">
                            <h3 class="pbml-section-title">
                                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z"/></svg>
                                Color Mode Preset
                            </h3>
                            <p style="color:#64748b; margin-bottom:15px; font-size:13px;">Select a preset to auto-fill colors. You can still customize each color below.</p>
                            <div class="pbml-mode-switcher">
                                <div class="pbml-mode-btn <?php echo $o['color_mode'] === 'dark' ? 'active' : ''; ?>" data-mode="dark">
                                    <div class="mode-icon">🌙</div>
                                    <div class="mode-title">Dark Popup</div>
                                    <div class="mode-desc">Best for light/white websites</div>
                                    <div class="pbml-color-preview">
                                        <span class="pbml-color-swatch" style="background:#1e293b;"></span>
                                        <span class="pbml-color-swatch" style="background:#fbbf24;"></span>
                                        <span class="pbml-color-swatch" style="background:#ffffff;"></span>
                                    </div>
                                </div>
                                <div class="pbml-mode-btn <?php echo $o['color_mode'] === 'light' ? 'active' : ''; ?>" data-mode="light">
                                    <div class="mode-icon">☀️</div>
                                    <div class="mode-title">Light Popup</div>
                                    <div class="mode-desc">Best for dark websites</div>
                                    <div class="pbml-color-preview">
                                        <span class="pbml-color-swatch" style="background:#ffffff;"></span>
                                        <span class="pbml-color-swatch" style="background:#2563eb;"></span>
                                        <span class="pbml-color-swatch" style="background:#1e293b;"></span>
                                    </div>
                                </div>
                            </div>
                            <input type="hidden" name="pbml_options[color_mode]" id="pbml-color-mode" value="<?php echo esc_attr($o['color_mode']); ?>">
                        </div>
                        
                        <div class="pbml-section">
                            <h3 class="pbml-section-title">
                                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                                Timing
                            </h3>
                            <div class="pbml-grid">
                                <div class="pbml-field">
                                    <label>Show After (seconds)</label>
                                    <input type="number" name="pbml_options[show_after]" value="<?php echo esc_attr($o['show_after']); ?>" min="0">
                                    <div class="hint">Delay before popup appears</div>
                                </div>
                                <div class="pbml-field">
                                    <label>Close Button After (seconds)</label>
                                    <input type="number" name="pbml_options[close_icon_after]" value="<?php echo esc_attr($o['close_icon_after']); ?>" min="0">
                                    <div class="hint">Delay before X button shows</div>
                                </div>
                                <div class="pbml-field">
                                    <label>Cookie Days</label>
                                    <input type="number" name="pbml_options[cookie_days]" value="<?php echo esc_attr($o['cookie_days']); ?>" min="0">
                                    <div class="hint">Don't show again for X days (0 = Show Every Time)</div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- CONTENT -->
                    <div class="pbml-panel" data-panel="content">
                        <div class="pbml-section">
                            <h3 class="pbml-section-title">Popup Type</h3>
                            <div class="pbml-radio-group">
                                <label class="pbml-radio-option">
                                    <input type="radio" name="pbml_options[popup_type]" value="content" <?php checked((isset($o['popup_type']) ? $o['popup_type'] : 'content'), 'content'); ?> onchange="document.getElementById('pbml-type-image-opts').style.display='none';document.getElementById('pbml-type-content-opts').style.display='block';">
                                    <span>Content Based</span>
                                </label>
                                <label class="pbml-radio-option">
                                    <input type="radio" name="pbml_options[popup_type]" value="image" <?php checked((isset($o['popup_type']) ? $o['popup_type'] : 'content'), 'image'); ?> onchange="document.getElementById('pbml-type-image-opts').style.display='block';document.getElementById('pbml-type-content-opts').style.display='none';">
                                    <span>Image Based</span>
                                </label>
                            </div>
                        </div>

                        <div id="pbml-type-image-opts" style="<?php echo (isset($o['popup_type']) && $o['popup_type'] === 'image') ? 'display:block' : 'display:none'; ?>">
                            <div class="pbml-section">
                                <h3 class="pbml-section-title">Image Popup Settings</h3>
                                <div class="pbml-field">
                                    <label>Image Link URL</label>
                                    <input type="url" name="pbml_options[image_link]" value="<?php echo isset($o['image_link']) ? esc_url($o['image_link']) : ''; ?>" placeholder="https://">
                                    <div class="hint">Where should the user go when clicking the image? (Optional)</div>
                                </div>
                                <label class="pbml-toggle">
                                    <input type="checkbox" name="pbml_options[image_link_target]" value="1" <?php checked((isset($o['image_link_target']) ? $o['image_link_target'] : '0'), '1'); ?>>
                                    <span class="switch"></span>
                                    <div class="toggle-text">
                                        <div class="toggle-label">Open in New Tab</div>
                                    </div>
                                </label>
                            </div>
                        </div>
                        
                        <!-- Shared Image Upload (Used by both, logic handled by context) -->
                        <div class="pbml-section">
                             <h3 class="pbml-section-title">Popup Image</h3>
                             <div class="pbml-image-upload">
                                 <div class="pbml-image-preview <?php echo $o['popup_image'] ? 'has-image' : ''; ?>" id="pbml-preview">
                                     <?php if($o['popup_image']) echo '<img src="'.esc_url($o['popup_image']).'">'; else echo '<span style="color:#94a3b8">No image</span>'; ?>
                                 </div>
                                 <div>
                                     <input type="hidden" name="pbml_options[popup_image]" id="pbml-image-url" value="<?php echo esc_url($o['popup_image']); ?>">
                                     <button type="button" class="pbml-btn pbml-btn-secondary" id="pbml-upload-btn">Select Image</button>
                                     <button type="button" class="pbml-btn pbml-btn-secondary" id="pbml-remove-btn" style="<?php echo !$o['popup_image'] ? 'display:none' : ''; ?>">Remove</button>
                                 </div>
                             </div>
                             <div class="hint">For "Content Based": displayed at top. For "Image Based": acts as the popup.</div>
                        </div>

                        <div id="pbml-type-content-opts" style="<?php echo (!isset($o['popup_type']) || $o['popup_type'] === 'content') ? 'display:block' : 'display:none'; ?>">
                            <div class="pbml-section">
                                <h3 class="pbml-section-title">Headline & Description</h3>
                                <div class="pbml-field">
                                    <label>Headline</label>
                                    <input type="text" name="pbml_options[headline]" value="<?php echo esc_attr($o['headline']); ?>">
                                </div>
                                <div class="pbml-grid">
                                    <div class="pbml-field">
                                        <label>Headline Size (px)</label>
                                        <input type="number" name="pbml_options[headline_size]" value="<?php echo esc_attr($o['headline_size']); ?>">
                                    </div>
                                    <div class="pbml-field">
                                        <label>Headline Color</label>
                                        <input type="text" name="pbml_options[headline_color]" value="<?php echo esc_attr($o['headline_color']); ?>" class="pbml-color" id="pbml-headline-color">
                                    </div>
                                </div>
                                <div class="pbml-field">
                                    <label>Description</label>
                                    <textarea name="pbml_options[description]"><?php echo esc_textarea($o['description']); ?></textarea>
                                </div>
                                <div class="pbml-grid">
                                    <div class="pbml-field">
                                        <label>Description Size (px)</label>
                                        <input type="number" name="pbml_options[description_size]" value="<?php echo esc_attr($o['description_size']); ?>">
                                    </div>
                                    <div class="pbml-field">
                                        <label>Description Color</label>
                                        <input type="text" name="pbml_options[description_color]" value="<?php echo esc_attr($o['description_color']); ?>" class="pbml-color" id="pbml-desc-color">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- APPEARANCE -->
                    <div class="pbml-panel" data-panel="appearance">
                        <div class="pbml-section">
                            <h3 class="pbml-section-title">Popup Box</h3>
                            <div class="pbml-grid">
                                <div class="pbml-field">
                                    <label>Background Color</label>
                                    <input type="text" name="pbml_options[popup_bg_color]" value="<?php echo esc_attr($o['popup_bg_color']); ?>" class="pbml-color" id="pbml-popup-bg">
                                </div>
                                <div class="pbml-field">
                                    <label>Border Radius (px)</label>
                                    <input type="number" name="pbml_options[border_radius]" value="<?php echo esc_attr($o['border_radius']); ?>">
                                </div>
                                <div class="pbml-field">
                                    <label>Overlay Color</label>
                                    <input type="text" name="pbml_options[overlay_color]" value="<?php echo esc_attr($o['overlay_color']); ?>" class="pbml-color">
                                </div>
                                <div class="pbml-field">
                                    <label>Overlay Opacity</label>
                                    <input type="number" name="pbml_options[overlay_opacity]" value="<?php echo esc_attr($o['overlay_opacity']); ?>" min="0" max="1" step="0.05">
                                </div>
                            </div>
                            <div class="pbml-grid" style="margin-top:20px; border-top:1px solid #f1f5f9; padding-top:20px;">
                                <div class="pbml-field">
                                    <label>Desktop Width (px)</label>
                                    <input type="number" name="pbml_options[width_desktop]" value="<?php echo esc_attr($o['width_desktop']); ?>" min="200" max="1200">
                                </div>
                                <div class="pbml-field">
                                    <label>Tablet Width (px)</label>
                                    <input type="number" name="pbml_options[width_tablet]" value="<?php echo esc_attr($o['width_tablet']); ?>" min="200" max="1000">
                                </div>
                                <div class="pbml-field">
                                    <label>Mobile Width (px)</label>
                                    <input type="number" name="pbml_options[width_mobile]" value="<?php echo esc_attr($o['width_mobile']); ?>" min="200" max="600">
                                </div>
                            </div>
                        </div>
                        <div class="pbml-section">
                            <h3 class="pbml-section-title">Outline / Border</h3>
                            <label class="pbml-toggle" style="margin-bottom:20px;">
                                <input type="checkbox" name="pbml_options[enable_outline]" value="1" <?php checked($o['enable_outline'], '1'); ?>>
                                <span class="switch"></span>
                                <div class="toggle-text">
                                    <div class="toggle-label">Enable Outline</div>
                                    <div class="toggle-desc">Add a border around the popup</div>
                                </div>
                            </label>
                            <div class="pbml-grid">
                                <div class="pbml-field">
                                    <label>Outline Color</label>
                                    <input type="text" name="pbml_options[outline_color]" value="<?php echo esc_attr($o['outline_color']); ?>" class="pbml-color" id="pbml-outline-color">
                                </div>
                                <div class="pbml-field">
                                    <label>Outline Width (px)</label>
                                    <input type="number" name="pbml_options[outline_width]" value="<?php echo esc_attr($o['outline_width']); ?>" min="1" max="10">
                                </div>
                            </div>
                        </div>
                        <div class="pbml-section">
                            <h3 class="pbml-section-title">Close Button</h3>
                            <div class="pbml-grid">
                                <div class="pbml-field">
                                    <label>Close Button Color</label>
                                    <input type="text" name="pbml_options[close_btn_color]" value="<?php echo esc_attr($o['close_btn_color']); ?>" class="pbml-color" id="pbml-close-color">
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- BUTTON -->
                    <div class="pbml-panel" data-panel="button">
                        <div class="pbml-section">
                            <h3 class="pbml-section-title">Call-to-Action Button</h3>
                            <div class="pbml-grid">
                                <div class="pbml-field">
                                    <label>Button Text</label>
                                    <input type="text" name="pbml_options[button_text]" value="<?php echo esc_attr($o['button_text']); ?>">
                                </div>
                                <div class="pbml-field">
                                    <label>Button URL</label>
                                    <input type="url" name="pbml_options[button_url]" value="<?php echo esc_url($o['button_url']); ?>">
                                </div>
                                <label class="pbml-toggle" style="grid-column: 1 / -1;">
                                    <input type="checkbox" name="pbml_options[button_new_tab]" value="1" <?php checked($o['button_new_tab'], '1'); ?>>
                                    <span class="switch"></span>
                                    <div class="toggle-text">
                                        <div class="toggle-label">Open in New Tab</div>
                                    </div>
                                </label>
                                <div class="pbml-field">
                                    <label>Button Background</label>
                                    <input type="text" name="pbml_options[button_bg_color]" value="<?php echo esc_attr($o['button_bg_color']); ?>" class="pbml-color" id="pbml-btn-bg">
                                </div>
                                <div class="pbml-field">
                                    <label>Button Text Color</label>
                                    <input type="text" name="pbml_options[button_text_color]" value="<?php echo esc_attr($o['button_text_color']); ?>" class="pbml-color" id="pbml-btn-text">
                                </div>
                                <div class="pbml-field">
                                    <label>Button Radius (px)</label>
                                    <input type="number" name="pbml_options[button_radius]" value="<?php echo esc_attr($o['button_radius']); ?>">
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- TARGETING -->
                    <div class="pbml-panel" data-panel="targeting">
                        <div class="pbml-section">
                            <h3 class="pbml-section-title">Display Rules</h3>
                            <label class="pbml-toggle" style="margin-bottom:20px;">
                                <input type="checkbox" name="pbml_options[display_on_all]" value="1" <?php checked($o['display_on_all'], '1'); ?>>
                                <span class="switch"></span>
                                <div class="toggle-text">
                                    <div class="toggle-label">Show on All Pages</div>
                                    <div class="toggle-desc">Display popup on every page</div>
                                </div>
                            </label>
                            <div class="pbml-field">
                                <label>Exclude Page IDs</label>
                                <input type="text" name="pbml_options[exclude_pages]" value="<?php echo esc_attr($o['exclude_pages']); ?>" placeholder="e.g. 12, 45, 102">
                                <div class="hint">Comma-separated page/post IDs to hide popup</div>
                            </div>
                            <div class="pbml-field">
                                <label>Include Only Page IDs</label>
                                <input type="text" name="pbml_options[include_pages]" value="<?php echo esc_attr($o['include_pages']); ?>" placeholder="e.g. 5, 88">
                                <div class="hint">Only show on these IDs (ignored if "Show on All" is on)</div>
                            </div>
                        </div>
                        <div class="pbml-section">
                            <h3 class="pbml-section-title">Close Behavior</h3>
                            <div class="pbml-grid">
                                <label class="pbml-toggle">
                                    <input type="checkbox" name="pbml_options[close_on_esc]" value="1" <?php checked($o['close_on_esc'], '1'); ?>>
                                    <span class="switch"></span>
                                    <div class="toggle-text">
                                        <div class="toggle-label">Close on ESC</div>
                                    </div>
                                </label>
                                <label class="pbml-toggle">
                                    <input type="checkbox" name="pbml_options[close_on_overlay]" value="1" <?php checked($o['close_on_overlay'], '1'); ?>>
                                    <span class="switch"></span>
                                    <div class="toggle-text">
                                        <div class="toggle-label">Close on Overlay Click</div>
                                    </div>
                                </label>
                            </div>
                        </div>
                    </div>
                    
                    <!-- ADVANCED -->
                    <div class="pbml-panel" data-panel="advanced">
                        <div class="pbml-section">
                            <h3 class="pbml-section-title">Import / Export</h3>
                            <div style="display:flex; gap:12px; flex-wrap:wrap;">
                                <button type="button" class="pbml-btn pbml-btn-secondary" id="pbml-export-btn">📥 Export Settings</button>
                                <label class="pbml-btn pbml-btn-secondary" style="cursor:pointer;">
                                    📤 Import JSON File
                                    <input type="file" id="pbml-import-file" accept=".json" style="display:none;">
                                </label>
                            </div>
                            <div id="pbml-import-status" style="margin-top:15px; font-weight:600;"></div>
                        </div>
                    </div>
                    
                    <div class="pbml-footer">
                        <button type="submit" class="pbml-btn pbml-btn-primary">💾 Save All Settings</button>
                    </div>
                </form>
            </div>
        </div>
        <?php
    }

    public function enqueue_frontend_assets() {
        $o = $this->get_options();
        if ($o['enabled'] !== '1') return;
        $cid = get_queried_object_id();
        if ($o['display_on_all'] === '1') {
            if ($o['exclude_pages'] && in_array($cid, array_map('trim', explode(',', $o['exclude_pages'])))) return;
        } else {
            if (!$o['include_pages'] || !in_array($cid, array_map('trim', explode(',', $o['include_pages'])))) return;
        }
        wp_enqueue_style('pbml-popup', PBML_PLUGIN_URL . 'assets/popup.css', array(), PBML_VERSION);
        wp_enqueue_script('pbml-popup', PBML_PLUGIN_URL . 'assets/popup.js', array(), PBML_VERSION, true);
        wp_localize_script('pbml-popup', 'pbmlSettings', array(
            'showAfter' => absint($o['show_after']),
            'closeIconAfter' => absint($o['close_icon_after']),
            'closeOnOverlay' => $o['close_on_overlay'] == '1',
            'closeOnEsc' => $o['close_on_esc'] == '1',
            'cookieDays' => absint($o['cookie_days']),
        ));
        $rgba = $this->hex_to_rgba($o['overlay_color'], $o['overlay_opacity']);
        $outline = $o['enable_outline'] === '1' ? "border: {$o['outline_width']}px solid {$o['outline_color']};" : '';
        $css = ":root{
            --pbml-bg:{$o['popup_bg_color']};
            --pbml-overlay:{$rgba};
            --pbml-radius:{$o['border_radius']}px;
            --pbml-h-color:{$o['headline_color']};
            --pbml-h-size:{$o['headline_size']}px;
            --pbml-d-color:{$o['description_color']};
            --pbml-d-size:{$o['description_size']}px;
            --pbml-btn-bg:{$o['button_bg_color']};
            --pbml-btn-color:{$o['button_text_color']};
            --pbml-btn-radius:{$o['button_radius']}px;
            --pbml-close-color:{$o['close_btn_color']};
            --pbml-w-desktop:{$o['width_desktop']}px;
            --pbml-w-tablet:{$o['width_tablet']}px;
            --pbml-w-mobile:{$o['width_mobile']}px;
        } 
        .pbml-modal { max-width: var(--pbml-w-desktop) !important; {$outline} }
        @media screen and (max-width: 992px) { .pbml-modal { max-width: var(--pbml-w-tablet) !important; } }
        @media screen and (max-width: 600px) { .pbml-modal { max-width: var(--pbml-w-mobile) !important; } }";
        wp_add_inline_style('pbml-popup', $css);
    }

    private function hex_to_rgba($h, $o) {
        $h = str_replace('#', '', $h);
        if (strlen($h) == 3) $h = $h[0].$h[0].$h[1].$h[1].$h[2].$h[2];
        return sprintf('rgba(%d,%d,%d,%s)', hexdec(substr($h, 0, 2)), hexdec(substr($h, 2, 2)), hexdec(substr($h, 4, 2)), $o);
    }

    public function render_popup() {
        $o = $this->get_options();
        if ($o['enabled'] !== '1') return;
        
        $is_image_popup = (isset($o['popup_type']) && $o['popup_type'] === 'image');
        $modal_class = 'pbml-modal' . ($is_image_popup ? ' pbml-type-image' : '');
        $img_target_attr = (isset($o['image_link_target']) && $o['image_link_target'] === '1') ? ' target="_blank" rel="noopener noreferrer"' : '';
        $btn_target_attr = ($o['button_new_tab'] === '1') ? ' target="_blank" rel="noopener noreferrer"' : '';
        ?>
        <div id="pbml-overlay" class="pbml-overlay" aria-hidden="true">
            <div class="<?php echo esc_attr($modal_class); ?>">
                <button id="pbml-close" class="pbml-close" aria-label="Close" style="display:none;">×</button>
                
                <?php if ($is_image_popup && $o['popup_image']): ?>
                    <div class="pbml-image-only">
                        <?php if(!empty($o['image_link'])): ?>
                            <a href="<?php echo esc_url($o['image_link']); ?>"<?php echo $img_target_attr; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>>
                                <img src="<?php echo esc_url($o['popup_image']); ?>" alt="Popup">
                            </a>
                        <?php else: ?>
                            <img src="<?php echo esc_url($o['popup_image']); ?>" alt="Popup">
                        <?php endif; ?>
                    </div>
                <?php else: ?>
                    <?php if ($o['popup_image']) echo '<div class="pbml-image"><img src="'.esc_url($o['popup_image']).'" alt=""></div>'; ?>
                    <div class="pbml-body">
                        <?php if ($o['headline']) echo '<h2 class="pbml-headline">'.esc_html($o['headline']).'</h2>'; ?>
                        <?php if ($o['description']) echo '<p class="pbml-description">'.wp_kses_post($o['description']).'</p>'; ?>
                        <a href="<?php echo esc_url($o['button_url']); ?>" class="pbml-btn"<?php echo $btn_target_attr; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>><?php echo esc_html($o['button_text']); ?></a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        <?php
    }
}
Popup_Builder_Maker_Lite::get_instance();
