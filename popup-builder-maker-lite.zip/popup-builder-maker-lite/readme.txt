=== Popup Builder & Maker Lite ===
Contributors: waqarrasheed
Tags: popup, modal, popup maker, conversion, lead generation
Requires at least: 5.0
Tested up to: 6.9
Stable tag: 1.4.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

A lightweight, fast WordPress popup plugin with modern UI, dark/light mode, and full customization.

== Description ==

Popup Builder & Maker Lite is a powerful yet lightweight solution for creating stunning popups on your WordPress site. Designed with performance and user experience in mind, it allows you to build high-converting popups without bloating your website.

= Features =
* **Modern UI**: Clean and professional design for the admin and frontend.
* **Popup Types**: Support for both content-based (headline, description, button) and image-only popups.
* **Presets**: Easy toggle between Dark and Light mode presets to match your theme.
* **Responsive**: Fully optimized for mobile, tablet, and desktop with customizable widths.
* **Targeting**: Include or exclude specific pages/posts by ID.
* **Animations**: Smooth fade and scale entrance animations.
* **Import/Export**: Easily move your settings between different sites.
* **No Cookies (Optional)**: Choose between session-based or day-based cookie dismissal.

== Installation ==

1. Upload the `popup-builder-maker-lite` folder to the `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Navigate to **Settings > Popup Builder Lite** to customize your popup.

== Screenshots ==

1. Admin Dashboard with General settings.
2. Content customization with live preview features.
3. Display rules and targeting settings.

== Changelog ==

= 1.4.0 =
* Added Image Based Popup support.
* Added Popup URL "Open in New Tab" option.
* Added custom width settings for Desktop, Tablet, and Mobile.
* Fixed cookie logic for "Show Every Time" (0 days).
* Security hardening and escaping fixes.

= 1.0.0 =
* Initial release.
